DROP TABLE IF EXISTS accounts;

CREATE TABLE accounts (
    account_id CHAR(1) PRIMARY KEY,
    account_name VARCHAR(50),
    balance NUMERIC(10,2) CHECK (balance >= 0)
);

INSERT INTO accounts (account_id, account_name, balance) VALUES
('A', 'Account A', 1000.00),
('B', 'Account B', 500.00);

SELECT * FROM accounts;

UPDATE accounts
SET balance = balance - 100
WHERE account_id = 'A';



UPDATE accounts
SET balance = CASE
    WHEN account_id = 'A' THEN 1000.00
    WHEN account_id = 'B' THEN 500.00
END;

SELECT * FROM accounts;


BEGIN;

UPDATE accounts
SET balance = balance - 100
WHERE account_id = 'A';

UPDATE accounts
SET balance = balance + 100
WHERE account_id = 'B';

COMMIT;

SELECT * FROM accounts;

BEGIN;

UPDATE accounts
SET balance = balance - 100
WHERE account_id = 'A';

UPDATE accounts
SET balance = balance + 100
WHERE account_id = 'B';

ROLLBACK;

SELECT * FROM accounts;





