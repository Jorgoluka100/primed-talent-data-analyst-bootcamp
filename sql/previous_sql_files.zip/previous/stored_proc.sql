-- Create the Customers table
CREATE TABLE Customers (
    CustomerID INT PRIMARY KEY,
    FirstName VARCHAR(100),
    LastName VARCHAR(100),
    Email VARCHAR(100),
    Country VARCHAR(50)
);

-- Create the Orders table
CREATE TABLE Orders (
    OrderID INT PRIMARY KEY,
    CustomerID INT,
    OrderDate DATE,
    TotalAmount DECIMAL(10, 2),
    FOREIGN KEY (CustomerID) REFERENCES Customers(CustomerID)
);

-- Insert sample customers
INSERT INTO Customers (CustomerID, FirstName, LastName, Email, Country)
VALUES 
    (1, 'John', 'Smith', 'john.smith@email.com', 'UK'),
    (2, 'Sarah', 'Johnson', 'sarah.johnson@email.com', 'UK'),
    (3, 'Michael', 'Brown', 'michael.brown@email.com', 'USA'),
    (4, 'Emma', 'Davis', 'emma.davis@email.com', 'UK');

-- Insert sample orders
INSERT INTO Orders (OrderID, CustomerID, OrderDate, TotalAmount)
VALUES 
    (101, 1, '2024-01-15', 150.00),
    (102, 1, '2024-02-20', 200.00),
    (103, 2, '2024-01-10', 75.50),
    (104, 3, '2024-02-05', 300.00),
    (105, 1, '2024-03-01', 125.00),
    (106, 2, '2024-03-10', 89.99);

-- Verify the data
SELECT * FROM Customers;
SELECT * FROM Orders;

-- Traditional approach: Write this query every time you need customer orders
-- Problem: This is repetitive and error-prone

SELECT 
    o.OrderID,
    c.FirstName,
    c.LastName,
    c.Email,
    o.OrderDate,
    o.TotalAmount
FROM Orders o
INNER JOIN Customers c ON o.CustomerID = c.CustomerID
WHERE o.CustomerID = 1;  -- Hardcoded for Customer 1

-- CREATE PROCEDURE procedure_name (
--     parameter_name parameter_type
-- )
-- LANGUAGE plpgsql
-- AS $$
-- BEGIN
--     -- Your SQL logic here
-- END;
-- $$;--

-- Create the stored procedure
-- This procedure takes one input: CustomerID (an integer)
-- It returns all orders for that customer
CREATE OR REPLACE FUNCTION sp_GetCustomerOrders(p_CustomerID INT)
RETURNS TABLE(OrderID INT, FirstName VARCHAR, LastName VARCHAR, 
              Email VARCHAR, OrderDate DATE, TotalAmount DECIMAL)
LANGUAGE plpgsql
AS $$
BEGIN
    RETURN QUERY
    SELECT 
        o.OrderID,
        c.FirstName,
        c.LastName,
        c.Email,
        o.OrderDate,
        o.TotalAmount
    FROM Orders o
    INNER JOIN Customers c ON o.CustomerID = c.CustomerID
    WHERE o.CustomerID = p_CustomerID;
END;
$$;

-- Call it:
SELECT * FROM sp_GetCustomerOrders(1);



