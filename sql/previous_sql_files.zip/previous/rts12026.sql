-- ============================================================================
-- PHASE 1: INITIALIZE DATABASE SCHEMA
-- ============================================================================

-- 1. Accounts Table: Holds current user balances
CREATE TABLE accounts (
    user_id SERIAL PRIMARY KEY,
    username TEXT NOT NULL,
    balance NUMERIC(15, 2) DEFAULT 0.00
);

-- 2. DailyTrades Table: Holds pending trades for the current day
CREATE TABLE daily_trades (
    trade_id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES accounts(user_id),
    symbol TEXT NOT NULL,
    quantity INTEGER NOT NULL,
    price_at_execution NUMERIC(12, 2) NOT NULL,
    profit_loss NUMERIC(12, 2) NOT NULL, -- Calculated during execution
    status TEXT DEFAULT 'Pending'        -- 'Pending' or 'Processed'
);

-- 3. TradesHistory Table: Archive for processed trades
CREATE TABLE trades_history (
    trade_id INTEGER PRIMARY KEY,
    user_id INTEGER,
    symbol TEXT,
    quantity INTEGER,
    profit_loss NUMERIC(12, 2),
    processed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 4. ProcessLog Table: Audit trail for the reconciliation process (with step tracking)
CREATE TABLE process_log (
    log_id SERIAL PRIMARY KEY,
    process_name TEXT DEFAULT 'End-of-Day Reconciliation',
    step_number INTEGER,           -- Track which step in the process
    trades_count INTEGER,
    status TEXT,
    message TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================================
-- PHASE 2: LOAD SAMPLE DATA
-- ============================================================================

INSERT INTO accounts (username, balance) VALUES ('trader_alpha', 10000.00), ('trader_beta', 5000.00);
INSERT INTO daily_trades (user_id, symbol, quantity, price_at_execution, profit_loss, status) 
VALUES (1, 'AAPL', 10, 150.00, 500.00, 'Pending'), (2, 'TSLA', 5, 700.00, -200.00, 'Pending');

-- ============================================================================
-- PHASE 3: DEFINE RECONCILIATION PROCEDURE WITH PROGRESS TRACKING
-- ============================================================================

CREATE OR REPLACE PROCEDURE sp_ReconcileDailyTrades()
LANGUAGE plpgsql
AS $$
DECLARE
    trade_record RECORD;           -- Variable to hold each trade during the loop
    v_trades_count INTEGER;        -- Variable to store number of pending trades
    v_current_step INTEGER := 1;   -- Track progress through procedure steps
    v_trades_processed INTEGER := 0; -- Counter for trades processed
BEGIN
    -- ========================================================================
    -- STEP 1: Initialize Process & Count Pending Trades
    -- ========================================================================
    SELECT COUNT(*) INTO v_trades_count FROM daily_trades WHERE status = 'Pending';
    
    INSERT INTO process_log (step_number, trades_count, status, message) 
    VALUES (v_current_step, v_trades_count, 'PHASE_1_INITIALIZED', 
            'Reconciliation process started. Found ' || v_trades_count || ' pending trades.');
    
    v_current_step := v_current_step + 1;

    -- ========================================================================
    -- STEP 2: Begin Processing Loop - Update Balances & Archive Trades
    -- ========================================================================
    INSERT INTO process_log (step_number, trades_count, status, message) 
    VALUES (v_current_step, v_trades_count, 'PHASE_2_LOOP_START', 
            'Beginning processing of pending trades...');
    
    v_current_step := v_current_step + 1;

    -- 2a. LOOP THROUGH TRADES: Process only 'Pending' trades (Idempotency check)
    FOR trade_record IN 
        SELECT * FROM daily_trades WHERE status = 'Pending'
        ORDER BY trade_id
    LOOP
        -- Step 2a-i: UPDATE Accounts - Adjust user balance based on profit/loss
        UPDATE accounts 
        SET balance = balance + trade_record.profit_loss 
        WHERE user_id = trade_record.user_id;

        -- Step 2a-ii: ARCHIVE Trade - Move data to the history table
        INSERT INTO trades_history (trade_id, user_id, symbol, quantity, profit_loss)
        VALUES (trade_record.trade_id, trade_record.user_id, trade_record.symbol, 
                trade_record.quantity, trade_record.profit_loss);

        -- Step 2a-iii: UPDATE Status - Mark as processed (Ensures idempotency if run again)
        UPDATE daily_trades 
        SET status = 'Processed' 
        WHERE trade_id = trade_record.trade_id;
        
        v_trades_processed := v_trades_processed + 1;
        
        -- Log progress every trade (optional: can be made conditional if too verbose)
        INSERT INTO process_log (step_number, trades_count, status, message) 
        VALUES (v_current_step, v_trades_count, 'TRADE_PROCESSED', 
                'Trade #' || trade_record.trade_id || ' (' || trade_record.symbol || 
                ') processed. User balance updated. Progress: ' || v_trades_processed || '/' || v_trades_count);
    END LOOP;

    v_current_step := v_current_step + 1;

    -- ========================================================================
    -- STEP 3: Finalize & Commit All Changes
    -- ========================================================================
    INSERT INTO process_log (step_number, trades_count, status, message) 
    VALUES (v_current_step, v_trades_count, 'PHASE_3_VALIDATION', 
            'All ' || v_trades_processed || ' trades archived and balances updated. Validating changes...');
    
    v_current_step := v_current_step + 1;

    -- 3a. COMMIT: Save all changes if the loop completes without error
    INSERT INTO process_log (step_number, trades_count, status, message) 
    VALUES (v_current_step, v_trades_count, 'SUCCESS', 
            'Reconciliation complete! ' || v_trades_processed || '/' || v_trades_count || 
            ' trades processed successfully. Transaction committed.');
    
    COMMIT;

EXCEPTION
    -- ========================================================================
    -- ERROR HANDLING: Rollback if any step fails
    -- ========================================================================
    WHEN OTHERS THEN
        ROLLBACK;
        
        -- Log the failure to the audit trail (independent transaction)
        INSERT INTO process_log (step_number, trades_count, status, message) 
        VALUES (v_current_step, v_trades_processed, 'FAILED', 
                'Error at step ' || v_current_step || '. Processed ' || v_trades_processed || 
                ' of ' || v_trades_count || ' trades before failure. ' ||
                'Entire transaction rolled back. Error: ' || SQLERRM);
        COMMIT; -- Commit the log entry itself
END;
$$;

-- ============================================================================
-- PHASE 4: CONFIGURE SECURITY & PERMISSIONS
-- ============================================================================

-- Revoke all permissions from public
REVOKE ALL ON PROCEDURE sp_ReconcileDailyTrades() FROM PUBLIC;

-- Grant execute permission only to the service account (replace 'service_user' with actual role)
-- GRANT EXECUTE ON PROCEDURE sp_ReconcileDailyTrades() TO service_user;

-- ============================================================================
-- PHASE 5: EXECUTE RECONCILIATION PROCESS
-- ============================================================================

-- Execute the main reconciliation process
CALL sp_ReconcileDailyTrades();

-- ============================================================================
-- PHASE 6: VIEW PROGRESS REPORT & RESULTS
-- ============================================================================

-- View the complete audit trail with step-by-step progress
SELECT 
    log_id,
    step_number,
    trades_count,
    status,
    message,
    created_at
FROM process_log
ORDER BY created_at DESC;

-- Summary of the reconciliation results
SELECT 
    'ACCOUNTS AFTER RECONCILIATION' as Report,
    user_id,
    username,
    balance
FROM accounts
ORDER BY user_id;

-- Archive verification - all processed trades
SELECT 
    'TRADES ARCHIVED' as Report,
    COUNT(*) as total_archived,
    SUM(profit_loss) as total_profit_loss
FROM trades_history;

-- Pending trades remaining (should be 0 if successful)
SELECT 
    'REMAINING PENDING TRADES' as Report,
    COUNT(*) as pending_count
FROM daily_trades
WHERE status = 'Pending';