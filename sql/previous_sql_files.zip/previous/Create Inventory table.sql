-- Create Inventory table
CREATE TABLE inventory (
    product_id SERIAL PRIMARY KEY,    -- Unique ID for the item
    product_name TEXT NOT NULL,       -- Name of the item
    quantity INTEGER NOT NULL         -- Current stock level
);

-- Create Sales table
CREATE TABLE sales (
    id SERIAL PRIMARY KEY,            -- Unique transaction ID
    product_id INTEGER REFERENCES inventory(product_id), -- Link to inventory
    status TEXT NOT NULL              -- Current status (e.g., 'Sold', 'Returned')
);

-- Insert sample data: 10 Laptops in stock and 1 specific sale record
INSERT INTO inventory (product_name, quantity) VALUES ('Laptop', 10);
INSERT INTO sales (product_id, status) VALUES (1, 'Sold');

-- query to look up the sales table 
SELECT * FROM sales;
SELECT * FROM inventory;

/* STEP 1: RESOLUTION - THE TRANSACTIONAL PROCEDURE
   This handles the "Process Return" operation as a single, atomic unit.
*/

CREATE OR REPLACE PROCEDURE pr_process_item_return(
    p_sale_id INT,        -- Parameter: The ID of the sale being reversed
    p_product_id INT      -- Parameter: The ID of the product being restocked
)
LANGUAGE plpgsql
AS $$
BEGIN
    -- BEGIN TRANSACTION (In Postgres procedures, the block starts the transaction)

    -- UPDATE 1: Increase Inventory
    -- This adds the item back to the warehouse stock
    UPDATE inventory 
    SET quantity = quantity + 1 
    WHERE product_id = p_product_id;

    -- UPDATE 2: Update Sales Record
    -- This changes the status from 'Sold' to 'Returned' for bookkeeping
    UPDATE sales 
    SET status = 'Returned' 
    WHERE id = p_sale_id;

    -- COMMIT: If both lines above work, save changes permanently
    COMMIT;

EXCEPTION
    -- CATCH: If any error occurs (e.g. database disconnect, constraint error)
    WHEN OTHERS THEN
        -- ROLLBACK: Undo everything inside this BEGIN block
        -- This prevents "partial updates" where stock rises but sale stays 'Sold'
        ROLLBACK;
        
        -- Log/Report the failure
        RAISE NOTICE 'An error occurred. Transaction rolled back for Sale ID %', p_sale_id;
END;
$$;

-- 1. Check current state (Quantity: 10, Status: 'Sold')
SELECT * FROM inventory;
SELECT * FROM sales;

-- 2. Execute the procedure
CALL pr_process_item_return(1, 1);

-- 3. Verify the atomic update (Quantity: 11, Status: 'Returned')
SELECT * FROM inventory;
SELECT * FROM sales;

/* 1. DATA AUDIT QUERY
   This identifies records that are inconsistent. 
   We look for sales marked 'Returned' that might have missed their inventory update.
*/
SELECT 
    s.id AS sale_id,
    s.product_id,
    s.status,
    i.product_name,
    i.quantity AS current_inventory
FROM sales s
JOIN inventory i ON s.product_id = i.product_id
WHERE s.status = 'Returned'; 
-- In a real production environment, you would join against an 'audit_log' 
-- table to see if a +1 quantity increase ever actually occurred for these IDs.

/* 2. DATA FIX (RECONCILIATION)
   This one-time update fixes the records found in the audit.
   We use a Subquery to increase inventory only for products that have 
   returned sales which weren't accounted for.
*/
UPDATE inventory
SET quantity = quantity + (
    SELECT COUNT(*) 
    FROM sales 
    WHERE sales.product_id = inventory.product_id 
    AND sales.status = 'Returned'
)
WHERE product_id IN (
    SELECT product_id 
    FROM sales 
    WHERE status = 'Returned'
);
-- This query synchronizes the inventory count with the total number of returns found in the sales table.

-- Final verification of inventory and sales tables
SELECT * FROM inventory;
SELECT * FROM sales;

-- create an "Audit Log" table and a Trigger that automatically records every time an inventory change is made