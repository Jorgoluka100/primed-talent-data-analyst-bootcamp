-- 1.1 Create CATEGORY table
DROP TABLE IF EXISTS category CASCADE;

CREATE TABLE category (
    category_id     SERIAL PRIMARY KEY,
    name            VARCHAR(50) NOT NULL,
    last_update     TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 1.2 Create FILM table
DROP TABLE IF EXISTS film CASCADE;

CREATE TABLE film (
    film_id         SERIAL PRIMARY KEY,
    title           VARCHAR(200) NOT NULL,
    rental_rate     DECIMAL(4,2) DEFAULT 4.99,
    last_update     TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 1.3 Create FILM_CATEGORY junction table (many-to-many relationship)
DROP TABLE IF EXISTS film_category CASCADE;

CREATE TABLE film_category (
    film_id         INT REFERENCES film(film_id),
    category_id     INT REFERENCES category(category_id),
    last_update     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (film_id, category_id)
);

-- 1.4 Create INVENTORY table
DROP TABLE IF EXISTS inventory CASCADE;

CREATE TABLE inventory (
    inventory_id    SERIAL PRIMARY KEY,
    film_id         INT REFERENCES film(film_id),
    store_id        INT DEFAULT 1,
    last_update     TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 1.5 Create CUSTOMER table
DROP TABLE IF EXISTS customer CASCADE;

CREATE TABLE customer (
    customer_id     SERIAL PRIMARY KEY,
    first_name      VARCHAR(50) NOT NULL,
    last_name       VARCHAR(50) NOT NULL,
    email           VARCHAR(100),
    last_update     TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 1.6 Create RENTAL table
DROP TABLE IF EXISTS rental CASCADE;

CREATE TABLE rental (
    rental_id       SERIAL PRIMARY KEY,
    rental_date     TIMESTAMP NOT NULL,
    inventory_id    INT REFERENCES inventory(inventory_id),
    customer_id     INT REFERENCES customer(customer_id),
    return_date     TIMESTAMP,
    last_update     TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 1.7 Create PAYMENT table
DROP TABLE IF EXISTS payment CASCADE;

CREATE TABLE payment (
    payment_id      SERIAL PRIMARY KEY,
    customer_id     INT REFERENCES customer(customer_id),
    rental_id       INT REFERENCES rental(rental_id),
    amount          DECIMAL(5,2) NOT NULL,
    payment_date    TIMESTAMP NOT NULL
);

----DATA INSERTION---------------------

-- 2.1 Insert categories
INSERT INTO category (name) VALUES
    ('Action'),      -- category_id = 1
    ('Comedy'),      -- category_id = 2
    ('Drama'),       -- category_id = 3
    ('Sci-Fi'),      -- category_id = 4
    ('Horror');      -- category_id = 5

-- 2.2 Insert films
INSERT INTO film (title, rental_rate) VALUES
    ('Speed Warriors', 4.99),       -- film_id = 1
    ('Laugh Factory', 2.99),        -- film_id = 2
    ('Tears of Joy', 3.99),         -- film_id = 3
    ('Galaxy Quest', 5.99),         -- film_id = 4
    ('Night Terrors', 4.99),        -- film_id = 5
    ('Fast Chase', 4.99),           -- film_id = 6
    ('Comedy Night', 2.99),         -- film_id = 7
    ('Space Odyssey', 5.99);        -- film_id = 8

-- 2.3 Insert film-category mappings (THE CRITICAL JUNCTION TABLE)
INSERT INTO film_category (film_id, category_id) VALUES
    (1, 1),  -- Speed Warriors -> Action
    (2, 2),  -- Laugh Factory -> Comedy
    (3, 3),  -- Tears of Joy -> Drama
    (4, 4),  -- Galaxy Quest -> Sci-Fi
    (5, 5),  -- Night Terrors -> Horror
    (6, 1),  -- Fast Chase -> Action
    (7, 2),  -- Comedy Night -> Comedy
    (8, 4);  -- Space Odyssey -> Sci-Fi

-- 2.4 Insert inventory (film copies available for rent)
INSERT INTO inventory (film_id) VALUES
    (1), (1), (2), (3), (4), (4), (5), (6), (7), (8);
-- inventory_ids: 1,2=film1, 3=film2, 4=film3, 5,6=film4, 7=film5, 8=film6, 9=film7, 10=film8

-- 2.5 Insert customers
INSERT INTO customer (first_name, last_name, email) VALUES
    ('John', 'Smith', 'john@email.com'),
    ('Jane', 'Doe', 'jane@email.com'),
    ('Bob', 'Wilson', 'bob@email.com'),
    ('Alice', 'Brown', 'alice@email.com');

-- 2.6 Insert rentals
INSERT INTO rental (rental_date, inventory_id, customer_id, return_date) VALUES
    ('2025-01-01 10:00:00', 1, 1, '2025-01-03 10:00:00'),  -- rental_id=1, film=Speed Warriors(Action)
    ('2025-01-01 11:00:00', 3, 2, '2025-01-02 11:00:00'),  -- rental_id=2, film=Laugh Factory(Comedy)
    ('2025-01-02 09:00:00', 5, 1, '2025-01-04 09:00:00'),  -- rental_id=3, film=Galaxy Quest(Sci-Fi)
    ('2025-01-02 14:00:00', 8, 3, '2025-01-05 14:00:00'),  -- rental_id=4, film=Fast Chase(Action)
    ('2025-01-03 10:00:00', 2, 4, '2025-01-06 10:00:00'),  -- rental_id=5, film=Speed Warriors(Action)
    ('2025-01-03 15:00:00', 9, 2, '2025-01-05 15:00:00'),  -- rental_id=6, film=Comedy Night(Comedy)
    ('2025-01-04 11:00:00', 10, 3, '2025-01-07 11:00:00'), -- rental_id=7, film=Space Odyssey(Sci-Fi)
    ('2025-01-04 16:00:00', 7, 4, '2025-01-06 16:00:00');  -- rental_id=8, film=Night Terrors(Horror)

-- 2.7 Insert payments
INSERT INTO payment (customer_id, rental_id, amount, payment_date) VALUES
    (1, 1, 4.99, '2025-01-01 10:05:00'),   -- Action film
    (2, 2, 2.99, '2025-01-01 11:05:00'),   -- Comedy film
    (1, 3, 5.99, '2025-01-02 09:05:00'),   -- Sci-Fi film
    (3, 4, 4.99, '2025-01-02 14:05:00'),   -- Action film
    (4, 5, 4.99, '2025-01-03 10:05:00'),   -- Action film
    (2, 6, 2.99, '2025-01-03 15:05:00'),   -- Comedy film
    (3, 7, 5.99, '2025-01-04 11:05:00'),   -- Sci-Fi film
    (4, 8, 4.99, '2025-01-04 16:05:00');   -- Horror film

-- 3.1 Verify row counts
SELECT 'category' AS table_name, COUNT(*) AS row_count FROM category
UNION ALL SELECT 'film', COUNT(*) FROM film
UNION ALL SELECT 'film_category', COUNT(*) FROM film_category
UNION ALL SELECT 'inventory', COUNT(*) FROM inventory
UNION ALL SELECT 'customer', COUNT(*) FROM customer
UNION ALL SELECT 'rental', COUNT(*) FROM rental
UNION ALL SELECT 'payment', COUNT(*) FROM payment;

-- 3.2 Preview the correct data path 
SELECT
    c.name AS category,
    COUNT(*) AS rentals,
    SUM(p.amount) AS expected_revenue
FROM payment p
JOIN rental r ON p.rental_id = r.rental_id
JOIN inventory i ON r.inventory_id = i.inventory_id
JOIN film f ON i.film_id = f.film_id
JOIN film_category fc ON f.film_id = fc.film_id
JOIN category c ON fc.category_id = c.category_id
GROUP BY c.name
ORDER BY expected_revenue DESC;

--Lineage Tracking Table

DROP TABLE IF EXISTS revenue_pipeline_lineage;

CREATE TABLE revenue_pipeline_lineage (
    step_number     INT PRIMARY KEY,
    step_name       VARCHAR(100) NOT NULL,
    source_table    VARCHAR(100),
    target_table    VARCHAR(100),
    join_keys       VARCHAR(200),
    transformation  VARCHAR(500),
    business_logic  VARCHAR(500),
    created_by      VARCHAR(50),
    last_validated  DATE
);


--DOCUMENT PIPELINE LINEAGE (WITH INTENTIONAL BUG)--

INSERT INTO revenue_pipeline_lineage VALUES
(1, 'Extract Payments',
    'payment', 'stg_payments',
    'payment_id (PK)',
    'SELECT payment_id, rental_id, amount, payment_date FROM payment',
    'Get all payment transactions',
    'junior_dev', '2024-01-15'),

(2, 'Join Payments to Rentals',
    'stg_payments, rental', 'stg_payment_rentals',
    'stg_payments.rental_id = rental.rental_id',
    'INNER JOIN on rental_id',
    'Link payment to rental transaction',
    'junior_dev', '2024-01-15'),

(3, 'Join to Inventory',
    'stg_payment_rentals, inventory', 'stg_payment_inventory',
    'rental.inventory_id = inventory.inventory_id',
    'INNER JOIN on inventory_id',
    'Link rental to film copy',
    'junior_dev', '2024-01-15'),

(4, 'Join to Films',
    'stg_payment_inventory, film', 'stg_payment_films',
    'inventory.film_id = film.film_id',
    'INNER JOIN on film_id',
    'Get film details',
    'junior_dev', '2024-01-15'),

(5, 'Join to Categories',                                    -- BUG IS HERE!
    'stg_payment_films, category', 'final_revenue_by_category',
    'film.film_id = category.category_id',                   -- WRONG JOIN KEY!
    'INNER JOIN, then GROUP BY category.name',
    'Aggregate revenue by category',
    'junior_dev', NULL);

--VIEW LINEAGE DOCUMENTATION--

SELECT
    step_number,
    step_name,
    source_table || ' -> ' || target_table AS data_flow,
    join_keys,
    CASE
        WHEN last_validated IS NULL THEN 'NOT VALIDATED'
        ELSE 'Validated: ' || last_validated::TEXT
    END AS status
FROM revenue_pipeline_lineage
ORDER BY step_number;

--EXECUTE THE BUGGY PIPELINE--

SELECT
    c.name AS category_name,
    COUNT(p.payment_id) AS transactions,
    SUM(p.amount) AS total_revenue
FROM payment p
INNER JOIN rental r ON p.rental_id = r.rental_id
INNER JOIN inventory i ON r.inventory_id = i.inventory_id
INNER JOIN film f ON i.film_id = f.film_id
INNER JOIN category c ON f.film_id = c.category_id    -- BUG: Wrong join!
GROUP BY c.name
ORDER BY total_revenue DESC;

--INVESTIGATE THE DATA MODEL--
-- 8.1 Check if film table has category_id column
SELECT column_name FROM information_schema.columns
WHERE table_name = 'film';
-- Result: NO category_id column in film table!

-- 8.2 Check the film_category junction table
SELECT column_name FROM information_schema.columns
WHERE table_name = 'film_category';
-- Result: film_id AND category_id - this is the bridge!

-- 8.3 Show the correct relationship path
SELECT
    f.film_id,
    f.title,
    fc.category_id,
    c.name AS category
FROM film f
JOIN film_category fc ON f.film_id = fc.film_id
JOIN category c ON fc.category_id = c.category_id
ORDER BY f.film_id;

--THE CORRECTED PIPELINE--

SELECT
    c.name AS category_name,
    COUNT(p.payment_id) AS transactions,
    SUM(p.amount) AS total_revenue
FROM payment p
INNER JOIN rental r ON p.rental_id = r.rental_id
INNER JOIN inventory i ON r.inventory_id = i.inventory_id
INNER JOIN film f ON i.film_id = f.film_id
INNER JOIN film_category fc ON f.film_id = fc.film_id         -- FIXED: Added junction table
INNER JOIN category c ON fc.category_id = c.category_id       -- FIXED: Correct join
GROUP BY c.name
ORDER BY total_revenue DESC;

--UPDATE LINEAGE DOCUMENTATION--

UPDATE revenue_pipeline_lineage
SET source_table = 'stg_payment_films, film_category, category',
    join_keys = 'film.film_id = film_category.film_id, film_category.category_id = category.category_id',
    transformation = 'INNER JOIN through film_category junction table, GROUP BY category.name',
    last_validated = CURRENT_DATE
WHERE step_number = 5;

-- Verify the fix
SELECT step_number, step_name, join_keys, last_validated
FROM revenue_pipeline_lineage
WHERE step_number = 5;