-- ===================================================================
-- TABLE 1: CATEGORIES
-- ===================================================================
CREATE TABLE categories (
    category_id INT PRIMARY KEY,
    category_name VARCHAR(100) NOT NULL
);

INSERT INTO categories VALUES 
    (1, 'Electronics'),
    (2, 'Furniture'),
    (3, 'Accessories'),
    (4, 'Office Supplies');

-- ===================================================================
-- TABLE 2: PRODUCTS
-- ===================================================================
CREATE TABLE products (
    product_id INT PRIMARY KEY,
    product_name VARCHAR(100) NOT NULL,
    category_id INT NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    stock_quantity INT DEFAULT 0,
    FOREIGN KEY (category_id) REFERENCES categories(category_id)
);

INSERT INTO products VALUES 
    -- Electronics
    (101, 'Laptop Pro', 1, 1200.00, 15),
    (102, 'Monitor 27"', 1, 300.00, 45),
    (103, 'Keyboard Mechanical', 1, 150.00, 60),
    (104, 'Mouse Wireless', 1, 50.00, 120),
    -- Furniture
    (201, 'Desk Executive', 2, 500.00, 20),
    (202, 'Chair Ergonomic', 2, 250.00, 35),
    (203, 'Bookshelf Oak', 2, 180.00, 15),
    (204, 'Filing Cabinet', 2, 120.00, 25),
    -- Accessories
    (301, 'USB-C Cable', 3, 25.00, 200),
    (302, 'Mouse Pad', 3, 20.00, 150),
    (303, 'Desk Lamp LED', 3, 45.00, 80),
    (304, 'Screen Stand', 3, 35.00, 90),
    -- Office Supplies
    (401, 'Pen Set', 4, 15.00, 300),
    (402, 'Notebook A4', 4, 8.00, 500),
    (403, 'Sticky Notes', 4, 5.00, 400),
    (404, 'Stapler', 4, 12.00, 100);

-- ===================================================================
-- TABLE 3: CUSTOMERS
-- ===================================================================
CREATE TABLE customers (
    customer_id INT PRIMARY KEY,
    customer_name VARCHAR(100) NOT NULL,
    email VARCHAR(100),
    city VARCHAR(50),
    join_date DATE
);

INSERT INTO customers VALUES 
    (1, 'John Smith', 'john@email.com', 'London', '2023-01-15'),
    (2, 'Sarah Johnson', 'sarah@email.com', 'Manchester', '2023-02-20'),
    (3, 'Michael Brown', 'michael@email.com', 'Leeds', '2023-03-10'),
    (4, 'Emma Davis', 'emma@email.com', 'London', '2023-04-05'),
    (5, 'James Wilson', 'james@email.com', 'Birmingham', '2023-05-12'),
    (6, 'Lisa Anderson', 'lisa@email.com', 'Liverpool', '2023-06-18'),
    (7, 'Robert Taylor', 'robert@email.com', 'Glasgow', '2023-07-22'),
    (8, 'Jennifer White', 'jennifer@email.com', 'London', '2023-08-30');

-- ===================================================================
-- TABLE 4: SALES REPS
-- ===================================================================
CREATE TABLE sales_reps (
    rep_id INT PRIMARY KEY,
    rep_name VARCHAR(100) NOT NULL,
    region VARCHAR(50),
    hire_date DATE
);

INSERT INTO sales_reps VALUES 
    (10, 'Alice Clark', 'North', '2022-01-10'),
    (11, 'Bob Wilson', 'South', '2022-03-15'),
    (12, 'Carol Martinez', 'East', '2022-05-20'),
    (13, 'David Lee', 'West', '2022-07-25');

-- ===================================================================
-- TABLE 5: ORDERS
-- ===================================================================
CREATE TABLE orders (
    order_id INT PRIMARY KEY,
    customer_id INT NOT NULL,
    order_date DATE NOT NULL,
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id)
);

INSERT INTO orders VALUES 
    -- John Smith (customer 1)
    (1001, 1, '2024-01-15'),
    (1002, 1, '2024-02-20'),
    (1003, 1, '2024-03-10'),
    -- Sarah Johnson (customer 2)
    (1004, 2, '2024-01-10'),
    (1005, 2, '2024-02-14'),
    -- Michael Brown (customer 3)
    (1006, 3, '2024-02-05'),
    -- Emma Davis (customer 4)
    (1007, 4, '2024-03-01'),
    (1008, 4, '2024-03-15'),
    -- James Wilson (customer 5)
    (1009, 5, '2024-02-28'),
    -- Lisa Anderson (customer 6)
    (1010, 6, '2024-03-05'),
    -- Robert Taylor (customer 7)
    (1011, 7, '2024-01-20'),
    -- Jennifer White (customer 8)
    (1012, 8, '2024-02-10');

-- ===================================================================
-- TABLE 6: ORDER_ITEMS (Order line items)
-- ===================================================================
CREATE TABLE order_items (
    item_id INT PRIMARY KEY,
    order_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(order_id),
    FOREIGN KEY (product_id) REFERENCES products(product_id)
);

INSERT INTO order_items VALUES 
    -- Order 1001 (John Smith)
    (5001, 1001, 101, 1, 1200.00),   -- 1 Laptop Pro
    (5002, 1001, 301, 2, 25.00),     -- 2 USB-C Cables
    -- Order 1002 (John Smith)
    (5003, 1002, 102, 1, 300.00),    -- 1 Monitor
    (5004, 1002, 303, 1, 45.00),     -- 1 Desk Lamp
    -- Order 1003 (John Smith)
    (5005, 1003, 201, 1, 500.00),    -- 1 Desk Executive
    -- Order 1004 (Sarah Johnson)
    (5006, 1004, 202, 2, 250.00),    -- 2 Chairs
    (5007, 1004, 301, 5, 25.00),     -- 5 USB-C Cables
    -- Order 1005 (Sarah Johnson)
    (5008, 1005, 103, 1, 150.00),    -- 1 Keyboard
    -- Order 1006 (Michael Brown)
    (5009, 1006, 102, 1, 300.00),    -- 1 Monitor
    (5010, 1006, 302, 3, 20.00),     -- 3 Mouse Pads
    -- Order 1007 (Emma Davis)
    (5011, 1007, 401, 10, 15.00),    -- 10 Pen Sets
    -- Order 1008 (Emma Davis)
    (5012, 1008, 402, 20, 8.00),     -- 20 Notebooks
    (5013, 1008, 403, 30, 5.00),     -- 30 Sticky Notes
    -- Order 1009 (James Wilson)
    (5014, 1009, 101, 1, 1200.00),   -- 1 Laptop Pro
    (5015, 1009, 202, 1, 250.00),    -- 1 Chair
    -- Order 1010 (Lisa Anderson)
    (5016, 1010, 203, 1, 180.00),    -- 1 Bookshelf
    -- Order 1011 (Robert Taylor)
    (5017, 1011, 304, 2, 35.00),     -- 2 Screen Stands
    -- Order 1012 (Jennifer White)
    (5018, 1012, 201, 1, 500.00);    -- 1 Desk Executive

	-- ===================================================================
-- TABLE 7: SALES (For GROUP BY Activity 2)
-- ===================================================================
CREATE TABLE sales (
    sale_id INT PRIMARY KEY,
    customer_id INT NOT NULL,
    product_id INT NOT NULL,
    rep_id INT NOT NULL,
    quantity INT NOT NULL,
    unit_price DECIMAL(10, 2) NOT NULL,
    sale_date DATE,
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id),
    FOREIGN KEY (product_id) REFERENCES products(product_id),
    FOREIGN KEY (rep_id) REFERENCES sales_reps(rep_id)
);

INSERT INTO sales VALUES 
    -- Alice Clark (rep_id 10)
    (2001, 1, 101, 10, 1, 1200.00, '2024-01-15'),
    (2002, 1, 301, 10, 2, 25.00, '2024-01-16'),
    (2003, 3, 102, 10, 1, 300.00, '2024-02-05'),
    (2004, 5, 101, 10, 1, 1200.00, '2024-02-28'),
    -- Bob Wilson (rep_id 11)
    (2005, 2, 202, 11, 2, 250.00, '2024-01-10'),
    (2006, 2, 103, 11, 1, 150.00, '2024-02-14'),
    (2007, 4, 401, 11, 10, 15.00, '2024-03-01'),
    -- Carol Martinez (rep_id 12)
    (2008, 6, 203, 12, 1, 180.00, '2024-03-05'),
    (2009, 7, 304, 12, 2, 35.00, '2024-01-20'),
    -- David Lee (rep_id 13)
    (2010, 4, 402, 13, 20, 8.00, '2024-03-15'),
    (2011, 8, 201, 13, 1, 500.00, '2024-02-10');

-- ===================================================================
-- VERIFICATION QUERIES - Run these to verify setup
-- ===================================================================

-- Check all tables created
SELECT tablename FROM pg_tables 
WHERE schemaname = 'public' 
ORDER BY tablename;

-- Count records in each table
SELECT 'categories' as table_name, COUNT(*) as row_count FROM categories
UNION ALL
SELECT 'products', COUNT(*) FROM products
UNION ALL
SELECT 'customers', COUNT(*) FROM customers
UNION ALL
SELECT 'sales_reps', COUNT(*) FROM sales_reps
UNION ALL
SELECT 'orders', COUNT(*) FROM orders
UNION ALL
SELECT 'order_items', COUNT(*) FROM order_items
UNION ALL
SELECT 'sales', COUNT(*) FROM sales
ORDER BY table_name;

-- ===================================================================
-- SAMPLE TEST QUERIES - Uncomment to verify data
-- ===================================================================
-- Test INNER JOIN (Activity 1)
SELECT 
    c.customer_name,
    o.order_id,
    o.order_date
FROM customers c
INNER JOIN orders o ON c.customer_id = o.customer_id
LIMIT 5;

-- Test LEFT JOIN (Activity 1)
SELECT 
    c.customer_name,
    COUNT(o.order_id) as order_count
FROM customers c
LEFT JOIN orders o ON c.customer_id = o.customer_id
GROUP BY c.customer_id, c.customer_name
ORDER BY order_count DESC;

-- Test GROUP BY with aggregates (Activity 2)

SELECT 
    cat.category_name,
    COUNT(p.product_id) as product_count,
    AVG(p.price) as avg_price
FROM categories cat
LEFT JOIN products p ON cat.category_id = p.category_id
GROUP BY cat.category_id, cat.category_name
ORDER BY product_count DESC;

-- Test data relationships
SELECT 
    c.customer_name,
    SUM(oi.quantity * oi.price) as total_spent,
    COUNT(DISTINCT o.order_id) as order_count
FROM customers c
LEFT JOIN orders o ON c.customer_id = o.customer_id
LEFT JOIN order_items oi ON o.order_id = oi.order_id
GROUP BY c.customer_id, c.customer_name
ORDER BY total_spent DESC NULLS LAST;




	