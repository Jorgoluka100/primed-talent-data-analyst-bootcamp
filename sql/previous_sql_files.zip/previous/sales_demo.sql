-- Create the Customers table
CREATE TABLE Customers (
    CustomerID INT PRIMARY KEY,
    CustomerName VARCHAR(100)
);

-- Create the Orders table with a Foreign Key
CREATE TABLE Orders (
    OrderID INT PRIMARY KEY,
    OrderDate DATE,
    CustomerID INT,
    Amount DECIMAL(10,2),
    FOREIGN KEY (CustomerID) REFERENCES Customers(CustomerID)
);

-- Insert sample data
INSERT INTO Customers VALUES (1, 'Alice Smith'), (2, 'Bob Jones');
INSERT INTO Orders VALUES (101, '2023-10-01', 1, 150.00), 
                           (102, '2023-10-05', 1, 200.00), 
                           (103, '2023-10-10', 2, 50.00);

SELECT * FROM Customers;
SELECT * FROM Orders;

-- Start creating the procedure
CREATE OR REPLACE PROCEDURE sp_GetCustomerOrders(
    IN p_CustomerID INT  -- Define an input parameter for the ID we want to find
)
LANGUAGE plpgsql
AS $$
-- The BEGIN and END keywords define the body of our logic
BEGIN
    -- We are joining the tables to find orders for our specific ID
    -- In this simple version, we output a message to the console
    RAISE NOTICE 'Searching for orders belonging to Customer ID: %', p_CustomerID;
    
    -- This logic represents the join that filters by the parameter
    -- Note: Standard Procedures in Postgres use 'CALL' and don't return tables directly
    -- to the 'Data Output' grid; they perform actions or logic.
    PERFORM c.CustomerName, o.OrderID 
    FROM Customers c 
    JOIN Orders o ON c.CustomerID = o.CustomerID 
    WHERE c.CustomerID = p_CustomerID;

END;
$$;

-- To run for Alice (ID 1)
CALL sp_GetCustomerOrders(1);
-- To run for Bob (ID 2)
CALL sp_GetCustomerOrders(2);



-- We use FUNCTION because it can return a result set (rows)
CREATE OR REPLACE FUNCTION fn_GetCustomerOrders(
    p_CustomerID INT -- Our input parameter
)
-- We must define the columns that the function will output
RETURNS TABLE(cust_name VARCHAR, order_num INT, order_total DECIMAL) 
LANGUAGE plpgsql
AS $$
BEGIN
    -- 'RETURN QUERY' tells PostgreSQL to send the results of the SELECT 
    -- directly to the user's data grid.
    RETURN QUERY
    SELECT c.CustomerName, o.OrderID, o.Amount
    FROM Customers c
    JOIN Orders o ON c.CustomerID = o.CustomerID
    WHERE c.CustomerID = p_CustomerID; -- Using our parameter here
END;
$$;

-- This will display Alice's orders in the 'Data Output' tab
SELECT * FROM fn_GetCustomerOrders(1);
-- This will display Bob's orders in the 'Data Output' tab
SELECT * FROM fn_GetCustomerOrders(2);

CREATE TABLE OrderItems (
    ItemID INT PRIMARY KEY,
    OrderID INT,
    ProductName VARCHAR(50),
    Quantity INT,
    FOREIGN KEY (OrderID) REFERENCES Orders(OrderID)
);

-- Start the transaction block
BEGIN; 

-- Step 1: Insert the main order record
INSERT INTO Orders (OrderID, OrderDate, CustomerID, Amount)
VALUES (201, '2023-11-01', 1, 30.00);

-- Step 2: Insert the specific items for that order
INSERT INTO OrderItems (ItemID, OrderID, ProductName, Quantity)
VALUES (501, 201, 'Mouse', 1),
       (502, 201, 'Mousepad', 1);

-- Step 3: Permanently save the changes to the disk
COMMIT;

-- VERIFICATION: Run this to see the data exists
SELECT * FROM Orders WHERE OrderID = 201;
SELECT * FROM OrderItems WHERE OrderID = 201;

-- Start a new transaction block
BEGIN;

-- Step 1: Insert a different order record
INSERT INTO Orders (OrderID, OrderDate, CustomerID, Amount)
VALUES (999, '2023-11-02', 2, 500.00);

-- Step 2: Insert the items
INSERT INTO OrderItems (ItemID, OrderID, ProductName, Quantity)
VALUES (801, 999, 'Monitor', 1);

-- Step 3: Decide to discard all changes made since 'BEGIN'
ROLLBACK;

-- VERIFICATION: Run these. You will see NO rows for Order 999.
-- It is as if the INSERT statements never happened.
SELECT * FROM Orders WHERE OrderID = 999;
SELECT * FROM OrderItems WHERE OrderID = 999;

