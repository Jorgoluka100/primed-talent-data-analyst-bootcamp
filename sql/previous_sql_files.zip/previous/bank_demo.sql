-- Create the Accounts table with sample data
-- This represents a simple bank with two accounts

CREATE TABLE Accounts (
    AccountID INT PRIMARY KEY,
    AccountName VARCHAR(100),
    Balance DECIMAL(10, 2)
);

-- Insert initial data: Account A with £1000, Account B with £500
INSERT INTO Accounts (AccountID, AccountName, Balance)
VALUES 
    (1, 'Account A', 1000.00),
    (2, 'Account B', 500.00);

-- Display the initial state of the table
SELECT * FROM Accounts;

-- FIRST UPDATE: Deduct £100 from Account A
UPDATE Accounts 
SET Balance = Balance - 100 
WHERE AccountID = 1;

-- [INSTRUCTOR PAUSES HERE - simulating a system crash]
-- The system crashes BEFORE we can run the second UPDATE
-- Let's check the current state:

SELECT * FROM Accounts;

-- Reset Account A back to £1000 so we can show the correct way
UPDATE Accounts 
SET Balance = 1000.00 
WHERE AccountID = 1;

-- Verify the reset
SELECT * FROM Accounts;

-- Start a transaction - everything that follows is now part of one atomic unit
BEGIN TRANSACTION;

    -- First UPDATE: Deduct £100 from Account A
    UPDATE Accounts 
    SET Balance = Balance - 100 
    WHERE AccountID = 1;
    
    -- Second UPDATE: Add £100 to Account B
    UPDATE Accounts 
    SET Balance = Balance + 100 
    WHERE AccountID = 2;

-- Commit the transaction - both changes are now permanent
COMMIT;

-- Verify the final state
SELECT * FROM Accounts;

-- Reset to starting balances for this demonstration
UPDATE Accounts SET Balance = 1000.00 WHERE AccountID = 1;
UPDATE Accounts SET Balance = 500.00 WHERE AccountID = 2;

-- Verify reset
SELECT 'Before transaction' AS State, * FROM Accounts;

-- ===== BEGIN TRANSACTION =====
BEGIN TRANSACTION;

    -- Update 1: Deduct £100 from Account A
    UPDATE Accounts 
    SET Balance = Balance - 100 
    WHERE AccountID = 1;
    
    -- Update 2: Add £100 to Account B
    UPDATE Accounts 
    SET Balance = Balance + 100 
    WHERE AccountID = 2;
    
    -- Check the state DURING the transaction (before commit/rollback)
    SELECT 'During transaction (before rollback)' AS State, * FROM Accounts;
    
    -- OOPS! We discovered a problem - this transfer was entered by mistake!
    -- Let's ROLLBACK and undo everything

ROLLBACK;

-- Check the state AFTER rollback
SELECT 'After rollback' AS State, * FROM Accounts;

-- Reset data
UPDATE Accounts SET Balance = 1000.00 WHERE AccountID = 1;
UPDATE Accounts SET Balance = 500.00 WHERE AccountID = 2;

-- Scenario: We're trying to transfer £1500 from Account A to Account B
-- But Account A only has £1000! This should fail.

BEGIN TRANSACTION;

    -- This will succeed - deduct £1500 from Account A (yes, it goes negative)
    UPDATE Accounts 
    SET Balance = Balance - 1500 
    WHERE AccountID = 1;
    
    -- This will succeed - add £1500 to Account B
    UPDATE Accounts 
    SET Balance = Balance + 1500 
    WHERE AccountID = 2;
    
    -- At this point, Account A has -£500 (overdraft!)
    -- Let's simulate a business rule check:
    -- "No account can have a balance below -£100"
    
    -- Check if Account A violates the rule
    SELECT Balance FROM Accounts WHERE AccountID = 1;
    -- Result: -500 - VIOLATES THE RULE!
    
    -- In a real application, this would trigger error handling
    ROLLBACK;  -- Undo the illegal transaction

-- Verify the accounts are back to normal
SELECT * FROM Accounts;

-- STUDENT PRACTICE: Complete the Transfer Transaction
-- Your task: Transfer £250 from Account B to Account A using a transaction

-- Step 1: Check starting balances
SELECT * FROM Accounts;

-- Step 2: Begin the transaction
BEGIN TRANSACTION;

    -- Step 3: Write the first UPDATE (deduct from Account B)
    UPDATE Accounts 
    SET Balance = Balance - 250 
    WHERE AccountID = 2;
    
    -- Step 4: Write the second UPDATE (add to Account A)
    UPDATE Accounts 
    SET Balance = Balance + 250 
    WHERE AccountID = 1;
    
    -- Step 5: Check intermediate state (optional - for learning)
    SELECT 'After updates but before commit' AS Status, * FROM Accounts;

-- Step 6: COMMIT to save the changes permanently
COMMIT;

-- Step 7: Verify final state
SELECT 'Final state' AS Status, * FROM Accounts;