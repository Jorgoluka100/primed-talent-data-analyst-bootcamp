--Simulate OLTP Database
CREATE TABLE oltp_customers(
    customer_id INT PRIMARY KEY,
	customer_name TEXT,
	email TEXT
);

CREATE TABLE oltp_orders(
    order_id INT PRIMARY KEY,
	customer_id INT,
	order_date DATE,
	order_amount DECIMAL(10,2),
	FOREIGN KEY (customer_id) REFERENCES oltp_customers(customer_id)
);

INSERT INTO oltp_customers VALUES
(1, 'Tom', 'tom@email.com'),
(2, 'Brad', 'brad@email.com'),
(3, 'Sam', 'sam@email.com');

INSERT INTO oltp_orders VALUES
(101, 1, '2025-01-01', 1200.00),
(102, 1, '2025-01-10', 800.00),
(103, 2, '2025-01-05', 500.00),
(104, 3, '2025-01-07', 1500.00);

SELECT
    c.customer_name,
	SUM(o.order_amount) AS revenue_90_days
FROM oltp_orders o
JOIN oltp_customers c on o.customer_id = c.customer_id
WHERE o.order_date >= CURRENT_DATE - INTERVAL '90 days'
GROUP BY c.customer_name;

-- Datawarehouse

CREATE TABLE dw_fact_sales(
    customer_id INT,
	customer_name TEXT,
	order_date DATE,
	order_amount DECIMAL(10,2)
);


--E-Extract from OLTP--
SELECT 
    o.customer_id,
	c.customer_name,
	o.order_date,
	o.order_amount
FROM oltp_orders o
JOIN oltp_customers c ON o.customer_id = c.customer_id;

--T-Transform (Clean and Join)
SELECT 
    o.customer_id,
	c.customer_name,
	o.order_date,
	o.order_amount
FROM oltp_orders o
JOIN oltp_customers c ON o.customer_id = c.customer_id;

--L-Load into a Datawarehouse

INSERT INTO dw_fact_sales
SELECT 
    o.customer_id,
	c.customer_name,
	o.order_date,
	o.order_amount
FROM oltp_orders o
JOIN oltp_customers c ON o.customer_id = c.customer_id;

SELECT * FROM dw_fact_sales;


--RUN analytics on OLAP

SELECT 
    customer_name,
	SUM(order_amount) AS revenue_90_days
FROM dw_fact_sales
WHERE order_date >= CURRENT_DATE - INTERVAL '90 days'
GROUP BY customer_name;


INSERT INTO oltp_orders VALUES
(105, 1, CURRENT_DATE, 650.00)

SELECT 
    o.order_amount,
	o.customer_id,
	o.order_date
FROM oltp_orders o;











