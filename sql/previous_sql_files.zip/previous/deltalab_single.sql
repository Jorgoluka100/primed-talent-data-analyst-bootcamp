DROP TABLE IF EXISTS source_transactions;

CREATE TABLE source_transactions (
    transaction_id          SERIAL PRIMARY KEY,
    customer_id             INT NOT NULL,
    order_total             DECIMAL(10,2) NOT NULL,
    transaction_status      VARCHAR(20) DEFAULT 'Pending',
    created_timestamp       TIMESTAMP NOT NULL,
    last_updated_timestamp  TIMESTAMP NOT NULL          -- Watermark column
);

CREATE INDEX idx_source_last_updated
ON source_transactions(last_updated_timestamp);

DROP TABLE IF EXISTS dw_transactions;
---Create warehouse table
CREATE TABLE dw_transactions(
   transaction_id INT PRIMARY KEY,
   customer_id INT NOT NULL,
   order_total DECIMAL(10,2) NOT NULL,
   transaction_status      VARCHAR(20) DEFAULT 'Pending',
   created_timestamp       TIMESTAMP NOT NULL,
   last_updated_timestamp  TIMESTAMP NOT NULL,
   loaded_timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
---Watermark Table-----
DROP TABLE IF EXISTS pipeline_watermark;

CREATE TABLE pipeline_watermark(
   pipeline_name VARCHAR(100) PRIMARY KEY,
   last_run_timestamp TIMESTAMP NOT NULL,
   rows_processed INT DEFAULT 0,
   load_status VARCHAR(20) DEFAULT 'SUCCESS'
);

---Data insertion in all tables--

INSERT INTO source_transactions
    (customer_id, order_total, transaction_status, created_timestamp, last_updated_timestamp)
VALUES
    (101, 150.00, 'Completed', '2025-01-01 10:00:00', '2025-01-01 10:00:00'),
    (102, 275.50, 'Completed', '2025-01-01 11:30:00', '2025-01-01 11:30:00'),
    (103, 89.99,  'Completed', '2025-01-02 09:15:00', '2025-01-02 09:15:00'),
    (104, 432.00, 'Completed', '2025-01-02 14:45:00', '2025-01-02 14:45:00'),
    (105, 67.25,  'Completed', '2025-01-03 08:00:00', '2025-01-03 08:00:00'),
    (106, 199.99, 'Completed', '2025-01-03 16:30:00', '2025-01-03 16:30:00'),
    (107, 550.00, 'Pending',   '2025-01-04 10:00:00', '2025-01-04 10:00:00'),
    (108, 125.75, 'Completed', '2025-01-04 12:00:00', '2025-01-04 12:00:00');

INSERT INTO source_transactions
    (customer_id, order_total, transaction_status, created_timestamp, last_updated_timestamp)
VALUES
    (109, 299.99, 'Completed', '2025-01-05 09:00:00', '2025-01-05 09:00:00'),
    (110, 175.50, 'Completed', '2025-01-05 10:30:00', '2025-01-05 10:30:00'),
    (111, 88.00,  'Pending',   '2025-01-05 11:45:00', '2025-01-05 11:45:00');

UPDATE source_transactions
SET
   transaction_status = 'Completed',
   last_updated_timestamp = '2025-01-05 14:00:00'
WHERE
   transaction_id = 7;

--Initialize the watermark---

INSERT INTO pipeline_watermark
(pipeline_name, last_run_timestamp, rows_processed, load_status) VALUES
('daily_transaction_load', '2025-01-04 23:59:59', 8, 'SUCCESS');


SELECT *
FROM source_transactions
ORDER BY transaction_id;

SELECT *
FROM pipeline_watermark;

--Preview delta records--

SELECT *
FROM source_transactions
WHERE last_updated_timestamp > '2025-01-04 23:59:59'
ORDER BY last_updated_timestamp;

--Compare total rows vs delta rows---

SELECT 
      (SELECT COUNT(*) FROM source_transactions) AS total_rows,
      (SELECT COUNT(*) FROM source_transactions
	   WHERE last_updated_timestamp > '2025-01-04 23:59:59') AS delta_rows;


--FULL LOAD IMPLEMENTATION--

TRUNCATE TABLE dw_transactions;

INSERT INTO dw_transactions
(transaction_id, customer_id, order_total, transaction_status, created_timestamp, last_updated_timestamp, loaded_timestamp)
SELECT
transaction_id, customer_id, order_total, transaction_status, created_timestamp, last_updated_timestamp, CURRENT_TIMESTAMP
FROM source_transactions;

SELECT COUNT(*) AS rows_loaded_full FROM dw_transactions;

--Delta Load---
TRUNCATE TABLE dw_transactions;

INSERT INTO dw_transactions (
    transaction_id, customer_id, order_total, transaction_status,
    created_timestamp, last_updated_timestamp, loaded_timestamp
)
SELECT
    transaction_id, customer_id, order_total, transaction_status,
    created_timestamp, last_updated_timestamp, CURRENT_TIMESTAMP
FROM source_transactions
WHERE last_updated_timestamp <= '2025-01-04 23:59:59';

SELECT COUNT(*) AS historical_rows FROM dw_transactions;

INSERT INTO dw_transactions (
    transaction_id, customer_id, order_total, transaction_status,
    created_timestamp, last_updated_timestamp, loaded_timestamp
)
SELECT
    transaction_id, customer_id, order_total, transaction_status,
    created_timestamp, last_updated_timestamp, CURRENT_TIMESTAMP
FROM source_transactions
WHERE last_updated_timestamp > '2025-01-04 23:59:59';

SELECT COUNT(*) AS total_after_delta FROM dw_transactions;


-- UPSERT (UPDATE + INSERT)

INSERT INTO dw_transactions (
    transaction_id, customer_id, order_total, transaction_status,
    created_timestamp, last_updated_timestamp, loaded_timestamp
)
SELECT
    transaction_id, customer_id, order_total, transaction_status,
    created_timestamp, last_updated_timestamp, CURRENT_TIMESTAMP
FROM source_transactions
WHERE last_updated_timestamp > '2025-01-04 23:59:59'
ON CONFLICT (transaction_id)
DO UPDATE SET
    customer_id = EXCLUDED.customer_id,
	order_total = EXCLUDED.order_total,
	transaction_status = EXCLUDED.transaction_status,
	last_updated_timestamp = EXCLUDED.last_updated_timestamp,
	loaded_timestamp = CURRENT_TIMESTAMP;

--UPDATE THE WATERMARK--

UPDATE pipeline_watermark
SET last_run_timestamp = (SELECT MAX(last_updated_timestamp)FROM source_transactions),
    rows_processed = (SELECT COUNT(*) FROM source_transactions
	                  WHERE last_updated_timestamp > '2025-01-04 23:59:59'),
	load_status='SUCCESS'
WHERE pipeline_name = 'daily_transaction_load';					  

SELECT * FROM pipeline_watermark;

-------------------------------







