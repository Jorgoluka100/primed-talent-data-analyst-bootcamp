-- 1. Create the Accounts table
CREATE TABLE Accounts (
    AccountName VARCHAR(1) PRIMARY KEY,
    Balance DECIMAL(10,2)
);

-- 2. Insert starting balances
INSERT INTO Accounts (AccountName, Balance) VALUES ('A', 1000.00), ('B', 500.00);

-- 3. Verify starting state
SELECT * FROM Accounts;

-- DEDUCT $100 from Account A
UPDATE Accounts SET Balance = Balance - 100 WHERE AccountName = 'A';

-- SIMULATE CRASH: Stop here! Do not run the next update.

-- Observe the data:
SELECT * FROM Accounts;
-- RESULT: A has $900, B has $500. $100 has vanished from the system!

-- Reset data first
UPDATE Accounts SET Balance = 1000 WHERE AccountName = 'A';
UPDATE Accounts SET Balance = 500 WHERE AccountName = 'B';

-- START THE TRANSACTION
BEGIN;

-- Operation 1: Deduct from A
UPDATE Accounts SET Balance = Balance - 100 WHERE AccountName = 'A';

-- Operation 2: Add to B
UPDATE Accounts SET Balance = Balance + 100 WHERE AccountName = 'B';

-- SAVE EVERYTHING PERMANENTLY
COMMIT;

-- Observe the data:
SELECT * FROM Accounts;
-- RESULT: A has $900, B has $600. The total ($1500) is preserved.

-- START THE TRANSACTION
BEGIN;

-- Deduct from A
UPDATE Accounts SET Balance = Balance - 100 WHERE AccountName = 'A';

-- Add to B
UPDATE Accounts SET Balance = Balance + 100 WHERE AccountName = 'B';

-- Wait... we realized we made a mistake (e.g., wrong account or wrong amount)
-- UNDO EVERYTHING
ROLLBACK;

-- Observe the data:
SELECT * FROM Accounts;
-- RESULT: A is back to $900, B is back to $600 (or whatever their state was before BEGIN).

