-- Drop tables if they already exist (safe for reruns)
DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS customers;

-- Create the Customers table
CREATE TABLE customers (
    customer_id INT PRIMARY KEY,          -- Unique identifier for each customer
    customer_name VARCHAR(100),            -- Name of the customer
    email VARCHAR(100)                     -- Email address of the customer
);

-- Create the Orders table
CREATE TABLE orders (
    order_id INT PRIMARY KEY,              -- Unique identifier for each order
    customer_id INT,                       -- Customer who placed the order
    order_date DATE,                       -- Date when the order was placed
    order_amount NUMERIC(10,2),            -- Total amount of the order

    -- Foreign key ensures orders belong to valid customers
    CONSTRAINT fk_customer
        FOREIGN KEY (customer_id)
        REFERENCES customers(customer_id)
);

-- Insert sample customers
INSERT INTO customers (customer_id, customer_name, email) VALUES
(1, 'Alice Johnson', 'alice@example.com'),
(2, 'Bob Smith', 'bob@example.com'),
(3, 'Charlie Brown', 'charlie@example.com');

-- Insert sample orders
INSERT INTO orders (order_id, customer_id, order_date, order_amount) VALUES
(101, 1, '2024-01-10', 250.00),
(102, 1, '2024-01-15', 180.00),
(103, 2, '2024-02-01', 300.00);

SELECT * FROM customers;
SELECT * FROM orders;




-- Create a function to return orders for a given customer
CREATE FUNCTION sp_GetCustomerOrders (
    p_customer_id INT          -- Input parameter: customer ID
)
RETURNS TABLE (
    customer_id INT,           -- Customer ID
    customer_name VARCHAR,     -- Customer name
    order_id INT,              -- Order ID
    order_date DATE,           -- Order date
    order_amount NUMERIC       -- Order total amount
)
LANGUAGE plpgsql
AS $$
BEGIN
    -- Return the result of the SELECT query
    RETURN QUERY
    SELECT
        c.customer_id,         -- Customer ID
        c.customer_name,       -- Customer name
        o.order_id,            -- Order ID
        o.order_date,          -- Date of the order
        o.order_amount         -- Order total amount
    FROM customers c
    JOIN orders o
        ON c.customer_id = o.customer_id   -- Join customers with orders
    WHERE c.customer_id = p_customer_id;   -- Filter using input parameter
END;
$$;

SELECT * FROM sp_GetCustomerOrders(1);
SELECT * FROM sp_GetCustomerOrders(2);








