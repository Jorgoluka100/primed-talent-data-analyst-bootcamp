-- 1.1 Create SOURCE rental table (simulates OLTP system)
DROP TABLE IF EXISTS rental CASCADE;

CREATE TABLE rental (
    rental_id       SERIAL PRIMARY KEY,
    rental_date     TIMESTAMP NOT NULL,
    inventory_id    INT NOT NULL,
    customer_id     INT NOT NULL,
    return_date     TIMESTAMP,
    staff_id        INT NOT NULL,
    last_update     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Create index on watermark column for delta query performance
CREATE INDEX idx_rental_last_update ON rental(last_update);

-- 1.2 Create SOURCE payment table
DROP TABLE IF EXISTS payment CASCADE;

CREATE TABLE payment (
    payment_id      SERIAL PRIMARY KEY,
    customer_id     INT NOT NULL,
    staff_id        INT NOT NULL,
    rental_id       INT REFERENCES rental(rental_id),
    amount          DECIMAL(5,2) NOT NULL,
    payment_date    TIMESTAMP NOT NULL,
    last_update     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_payment_last_update ON payment(last_update);

-- 1.3 Create TARGET staging table (Data Warehouse)
DROP TABLE IF EXISTS stg_rental CASCADE;

CREATE TABLE stg_rental (
    rental_id       INT PRIMARY KEY,
    rental_date     TIMESTAMP NOT NULL,
    inventory_id    INT NOT NULL,
    customer_id     INT NOT NULL,
    return_date     TIMESTAMP,
    staff_id        INT NOT NULL,
    last_update     TIMESTAMP NOT NULL,
    loaded_at       TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 1.4 Create ETL control/watermark table
DROP TABLE IF EXISTS etl_control CASCADE;

CREATE TABLE etl_control (
    table_name          VARCHAR(100) PRIMARY KEY,
    last_run_timestamp  TIMESTAMP NOT NULL,
    rows_processed      INT DEFAULT 0,
    status              VARCHAR(20) DEFAULT 'SUCCESS'
);



-- PART 2: DATA INSERTION


-- 2.1 Insert HISTORICAL rental data (before last ETL run - Jan 4, 2025)
INSERT INTO rental (rental_date, inventory_id, customer_id, return_date, staff_id, last_update)
VALUES
    ('2025-01-01 10:00:00', 101, 1, '2025-01-03 10:00:00', 1, '2025-01-01 10:00:00'),
    ('2025-01-01 11:30:00', 102, 2, '2025-01-02 11:30:00', 1, '2025-01-01 11:30:00'),
    ('2025-01-02 09:15:00', 103, 1, '2025-01-04 09:15:00', 2, '2025-01-02 09:15:00'),
    ('2025-01-02 14:45:00', 104, 3, '2025-01-05 14:45:00', 1, '2025-01-02 14:45:00'),
    ('2025-01-03 08:00:00', 105, 4, '2025-01-06 08:00:00', 2, '2025-01-03 08:00:00'),
    ('2025-01-03 16:30:00', 106, 2, NULL, 1, '2025-01-03 16:30:00'),
    ('2025-01-04 10:00:00', 107, 5, NULL, 2, '2025-01-04 10:00:00'),
    ('2025-01-04 12:00:00', 108, 3, '2025-01-07 12:00:00', 1, '2025-01-04 12:00:00');

-- 2.2 Insert NEW rental data (after last ETL run - the "delta")
INSERT INTO rental (rental_date, inventory_id, customer_id, return_date, staff_id, last_update)
VALUES
    ('2025-01-05 09:00:00', 109, 1, NULL, 1, '2025-01-05 09:00:00'),
    ('2025-01-05 10:30:00', 110, 6, NULL, 2, '2025-01-05 10:30:00'),
    ('2025-01-05 14:00:00', 111, 4, NULL, 1, '2025-01-05 14:00:00');

-- 2.3 Simulate an UPDATE (return processed after last ETL run)
UPDATE rental
SET return_date = '2025-01-05 16:00:00',
    last_update = '2025-01-05 16:00:00'
WHERE rental_id = 6;

UPDATE rental
SET return_date = '2025-01-05 17:00:00',
    last_update = '2025-01-05 17:00:00'
WHERE rental_id = 7;

-- 2.4 Insert payment data
INSERT INTO payment (customer_id, staff_id, rental_id, amount, payment_date, last_update)
VALUES
    (1, 1, 1, 4.99, '2025-01-01 10:05:00', '2025-01-01 10:05:00'),
    (2, 1, 2, 2.99, '2025-01-01 11:35:00', '2025-01-01 11:35:00'),
    (1, 2, 3, 5.99, '2025-01-02 09:20:00', '2025-01-02 09:20:00'),
    (3, 1, 4, 4.99, '2025-01-02 14:50:00', '2025-01-02 14:50:00'),
    (4, 2, 5, 3.99, '2025-01-03 08:05:00', '2025-01-03 08:05:00'),
    (2, 1, 6, 4.99, '2025-01-03 16:35:00', '2025-01-03 16:35:00'),
    (5, 2, 7, 2.99, '2025-01-04 10:05:00', '2025-01-04 10:05:00'),
    (3, 1, 8, 4.99, '2025-01-04 12:05:00', '2025-01-04 12:05:00'),
    (1, 1, 9, 5.99, '2025-01-05 09:05:00', '2025-01-05 09:05:00'),
    (6, 2, 10, 3.99, '2025-01-05 10:35:00', '2025-01-05 10:35:00');

-- 2.5 Initialize watermark (last successful run: Jan 4, 2025 23:59:59)
INSERT INTO etl_control (table_name, last_run_timestamp, rows_processed, status)
VALUES
    ('rental', '2025-01-04 23:59:59', 8, 'SUCCESS'),
    ('payment', '2025-01-04 23:59:59', 8, 'SUCCESS');

3. --VERIFY DATA SETUP--

-- 3.1 Check row counts
SELECT 'rental' AS table_name, COUNT(*) AS rows FROM rental
UNION ALL SELECT 'payment', COUNT(*) FROM payment
UNION ALL SELECT 'etl_control', COUNT(*) FROM etl_control;

-- 3.2 View watermark status
SELECT * FROM etl_control;

-- 3.3 Check for NULL in watermark column (should be 0)
SELECT COUNT(*) AS null_watermark_count FROM rental WHERE last_update IS NULL;


--IDENTIFY WATERMARK COLUMN--

--WRITE DELTA EXTRACTION SQL--

-- 5.1 Get current watermark value
SELECT last_run_timestamp FROM etl_control WHERE table_name = 'rental';

-- 5.2 Preview delta records (what will be extracted)
SELECT
    rental_id,
    rental_date,
    inventory_id,
    customer_id,
    return_date,
    staff_id,
    last_update
FROM rental
WHERE last_update > '2025-01-04 23:59:59'
ORDER BY last_update ASC;

-- 5.3 Count delta size
SELECT COUNT(*) AS delta_rows FROM rental
WHERE last_update > '2025-01-04 23:59:59';

-- 5.4 Delta extraction with upper bound (production pattern)
SELECT
    rental_id,
    rental_date,
    inventory_id,
    customer_id,
    return_date,
    staff_id,
    last_update
FROM rental
WHERE last_update > '2025-01-04 23:59:59'      -- Lower bound (exclusive)
  AND last_update <= '2025-01-05 23:59:59'     -- Upper bound (inclusive)
ORDER BY last_update ASC;

--EXECUTE DELTA LOAD--

-- 6.1 Load delta into staging table
INSERT INTO stg_rental (
    rental_id, rental_date, inventory_id, customer_id,
    return_date, staff_id, last_update, loaded_at
)
SELECT
    rental_id, rental_date, inventory_id, customer_id,
    return_date, staff_id, last_update, CURRENT_TIMESTAMP
FROM rental
WHERE last_update > '2025-01-04 23:59:59';

-- 6.2 Update watermark after successful load
UPDATE etl_control
SET last_run_timestamp = (SELECT MAX(last_update) FROM rental),
    rows_processed = (SELECT COUNT(*) FROM rental WHERE last_update > '2025-01-04 23:59:59'),
    status = 'SUCCESS'
WHERE table_name = 'rental';

-- 6.3 Verify results
SELECT 'Staging table rows:' AS metric, COUNT(*)::TEXT AS value FROM stg_rental
UNION ALL
SELECT 'New watermark:', last_run_timestamp::TEXT FROM etl_control WHERE table_name = 'rental';


