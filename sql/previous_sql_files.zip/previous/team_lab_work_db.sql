-- Setup Tables
CREATE TABLE Students (
    StudentID INT PRIMARY KEY,
    StudentName VARCHAR(100)
);

CREATE TABLE Courses (
    CourseID INT PRIMARY KEY,
    CourseName VARCHAR(100),
    SeatsAvailable INT
);

CREATE TABLE Enrollments (
    EnrollmentID SERIAL PRIMARY KEY,
    StudentID INT REFERENCES Students(StudentID),
    CourseID INT REFERENCES Courses(CourseID),
    EnrollmentDate TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert Sample Data
INSERT INTO Students VALUES (1, 'Alice'), (2, 'Bob');
INSERT INTO Courses VALUES (101, 'Database Systems', 1); -- Only 1 seat!

-- FILE: sp_EnrollStudent.sql

CREATE OR REPLACE PROCEDURE sp_EnrollStudent(
    IN p_StudentID INT,
    IN p_CourseID INT
)
LANGUAGE plpgsql
AS $$
DECLARE
    v_seats INT; -- Variable to store current seat count
BEGIN
    -- 1. Check current seat availability
    SELECT SeatsAvailable INTO v_seats 
    FROM Courses 
    WHERE CourseID = p_CourseID;

    -- 2. Logical Validation
    IF v_seats > 0 THEN
        -- Perform the enrollment
        INSERT INTO Enrollments (StudentID, CourseID)
        VALUES (p_StudentID, p_CourseID);

        -- Update the course table to decrement the seat count
        UPDATE Courses 
        SET SeatsAvailable = SeatsAvailable - 1
        WHERE CourseID = p_CourseID;

        -- Log success
        RAISE NOTICE 'Enrollment successful for Student % in Course %', p_StudentID, p_CourseID;
    ELSE
        -- Trigger an error if no seats are available
        -- This will automatically jump to the EXCEPTION block
        RAISE EXCEPTION 'Enrollment failed: Course % has no seats available.', p_CourseID;
    END IF;

-- Note: In a Procedure, if an EXCEPTION is raised, 
-- PostgreSQL automatically rolls back the current transaction.
EXCEPTION
    WHEN OTHERS THEN
        RAISE NOTICE 'Transaction Rolled Back: %', SQLERRM;
        ROLLBACK; -- Explicitly rolling back any partial changes
END;
$$;

-- CALL 1: Successful Enrollment (Alice takes the last seat)
CALL sp_EnrollStudent(1, 101);

-- CALL 2: Failed Enrollment (Bob tries to join, but seats are 0)
-- This should trigger the EXCEPTION and ROLLBACK
CALL sp_EnrollStudent(2, 101);

-- CALL 3: Verify Data
-- You should see Alice in Enrollments and 'Database Systems' with 0 seats.
SELECT * FROM Enrollments;
SELECT * FROM Courses;