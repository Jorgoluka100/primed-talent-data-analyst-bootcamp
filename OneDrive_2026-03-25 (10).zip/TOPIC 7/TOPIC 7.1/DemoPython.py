#Assignment 3:Lab Work

daily_sales = [1200, 1500, 1100, 1800, 1600]

# 1. Counting items (Number of days)
sales_count = len(daily_sales)

# 2. Finding totals
sales_total = sum(daily_sales)

# 3. Calculating averages
sales_average = sales_total / sales_count

print(f"Number of Days: {sales_count}")
print(f"Total Sales: ${sales_total}") 
print(f"Average Daily Sales: ${sales_average}")

product_stock = {
    "Laptop": 10,
    "Mouse": 50,
    "Keyboard": 30,
    "Monitor": 15
}

# 1. Counting items (Number of unique product types)
product_count = len(product_stock)

# 2. Finding totals (Sum of all quantities in stock)
total_items = sum(product_stock.values())

# 3. Calculating averages (Average quantity per product type)
average_stock = total_items / product_count

print(f"Product Types: {product_count}")
print(f"Total Stock Quantity: {total_items}")
print(f"Average Units per Product: {average_stock}")